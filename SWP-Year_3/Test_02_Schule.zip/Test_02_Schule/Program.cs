﻿namespace Test_02_Schule
{
    public class Program
    {
        static void Main() { }
    }
}