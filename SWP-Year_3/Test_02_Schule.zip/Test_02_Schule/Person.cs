﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_02_Schule
{
    class Person 
    {
        public string Name { get; set; }
        public string Geschlecht { get; set; }
        public DateTime Geburtsdatum { get; set; }
    }
}
